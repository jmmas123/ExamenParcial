import math

"""
***************************************************************
@@ ejercicio 1 @@
un metodo python que haga la suma de 3 numeros
2+4+6 = 12
"""


# start-->
def suma(x, y, z):
    return x + y + z


resultado = suma(2, 4, 6)
print("El resultado es: " + str(resultado))


"""
***************************************************************
@@ ejercicio 2 @@
la suma de los numeros impares del 1 al 1000
"""


# start-->
def sumaImpares(i, t):
    result = 0
    rango = range(i, t, 2)
    for x in rango:
        result = result + x
    if result == 250000:
        print("El resultado de la suma es: " + str(result))


sumaImpares(1, 1000)


"""
***************************************************************
@@ ejercicio 3 @@
encontrar el perimetro, area y el volumen de un esfera
radio = 12 m
perimetro: 2*pi*r
area: 4*pi*r^2
volumen: (4/3)*pi*r^3
"""

# start-->
def definicionEsfera(r):
    def obtenerPerimetro():
        pi = 3.1416
        p = 2 * pi * r
        print(p)

    def obtenerArea():
        pi = 3.1416
        a = 4 * (r ** 2) * pi
        print(a)

    def obtenerVolumen():
        pi = 3.1416
        v = (4 / 3) * pi * (r ** 3)
        print(v)


obtenerPerimetro = definicionEsfera(12)
obtenerArea = definicionEsfera(12)
obtenerVolumen = definicionEsfera(12)


"""
***************************************************************
@@ ejercicio 4 @@
el ejercicio numero 3 convertirlo en una clase
"""
"""



# start-->
class Esfera:
    def definicionEsfera(self):
        return 0

"""
"""
** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** *

@@ ejercicio 5 @@
Banco
Cliente
    nombre
    lugar
    numero de cuenta
    transaccion - retiro o abono
    monto
"""
"""


class Banco:
    def procesar(self):
        return 0

    def abonosSanSalvador(self):
        return 0

    def abonosBalYRod(self):
        return 0


class Cliente:
    pass

"""
"""
***************************************************************
@@ ejercicio 6 @@
colocar este proyecto en github
colocar aca debajo la url
ademas colocar la url en un archivo
github_<nombre>_<codigo>.txt y subirlo a moodle
"""


# github url-->
def getGithubUrl():
    return ""